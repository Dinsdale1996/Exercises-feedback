from turtle import color
from cv2 import sqrt
import tensorflow as tf
import numpy as np
from matplotlib import pyplot as plt
import cv2 as cv
import os 

def calcDistance(Xpoint1, Ypoint1, Xpoint2, Ypoint2):

    Xdifference = Xpoint1 - Xpoint2
    if (Xdifference < 0):
        Xdifference = Xdifference * -1
    
    Ydifference = Ypoint1 - Ypoint2
    if (Ydifference < 0):
        Ydifference = Ydifference * -1

    distance = (Xdifference ** 2) + (Ydifference ** 2)
    distance = sqrt(distance)

    return distance

def calcAngle(Xpoint1, Ypoint1, Xpoint2, Ypoint2, XpointJ, YpointJ):
    Djto1 = calcDistance(XpointJ, YpointJ, Xpoint1, Ypoint1)
    Djto2 = calcDistance(XpointJ, YpointJ, Xpoint2, Ypoint2)
    D1to2 = calcDistance(Xpoint1, Ypoint1, Xpoint2, Ypoint2)

    angle = 
    
    return angle